FireGem static deploy (Netlify & GitHub Pages)
==============================================

Contents
--------
- /offers/index.html       Landing (packages + Stripe buy links)
- /affiliates/index.html   Affiliate landing (tracking placeholder)
- netlify.toml             Netlify configuration (redirect root -> /offers/)
- _headers                 Optional HTTP security headers (Netlify)

Quick Deploy to Netlify (drag & drop)
-------------------------------------
1) Go to https://app.netlify.com/drop
2) Drag the entire 'firegem' folder into the drop zone.
3) After deploy, Netlify will give you a site URL like https://yourname.netlify.app
4) (Optional) Add your custom domain under Domain settings and set the root redirect already in netlify.toml.

GitHub Pages (repo deploy)
--------------------------
1) Create a new repo, e.g., firegem-site
2) Upload the 'firegem' folder contents to the repo root.
3) In GitHub, Settings → Pages:
   - Build and deployment: Deploy from a branch
   - Branch: main, folder: / (root)
4) Access the site at https://<your-user>.github.io/<repo>/offers/index.html
   (Optional) Use a custom domain via 'Pages' settings.

Testing
-------
- Open /offers/index.html in a normal browser (not an in-app viewer).
- Verify Stripe links open (they use https://buy.stripe.com/...).
- Test UTM & coupon passthrough:
  /offers/index.html?utm_source=tiktok&aff_id=creator123&coupon=FIRE10

Edits you may still want to make
--------------------------------
- Replace YOUR_EMAIL_HERE in forms with your email or form endpoint.
- Insert your affiliate tracking script URL in /affiliates/index.html (placeholder present).
- If you add a custom domain, set the root to redirect to /offers/ (Netlify already configured).
